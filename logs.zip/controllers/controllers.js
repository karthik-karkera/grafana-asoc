const authService = require('../services/authService');
const service = require('../services/service');
const sql = require('msnodesqlv8')
var log4js = require("log4js");
var logger = log4js.getLogger();

var methods = {};

// var dbConfig = {
//     server: process.env.SERVER,
//     database: process.env.DATABASE,
//     driver: process.env.DRIVER,
    
//     options: {
//         trustedConnection: true
//     }
// }
// const db = sql.connect(dbConfig, (err) => {
//     console.log(dbConfig)
//     if(err) throw err;
//     console.log("Connected")
// });

// const connectionString = "server=LP1-AP-52178079\SQLEXPRESS01;Database=asoc_grafana;Trusted_Connection=Yes;Driver=msnodesqlv8";
const connectionString = "server=LP1-AP-52178079\\SQLEXPRESS01;Database=asoc_grafana;Trusted_Connection=Yes;Driver={ODBC Driver 17 for SQL Server}";

methods.auth = async (req, res, next) => {
    try {
        if (!process.env.keyId || !process.env.keySecret) {
            logger.error('Unauthorized - Missing KeyId or KeySecret')
            return res.status(401).send(`Unauthorized - Missing KeyId or KeySecret`)
        }
        var inputData = {};
        inputData["keyId"] = process.env.keyId;
        inputData["keySecret"] = process.env.keySecret;
        const result = await authService.login(inputData);
        req.token = result.data.Token;
        next();
    } catch (err) {
        logger.error(`${err.response.status} - ${err.response.data.Message}`);
        return res.status(err.response.status).send(err.response.data.Message)
    }
}

methods.applicationList = async (req, res) => {
    if (!req.token) {
        console.log('No Token')
    }
    try {
        const appscanToken = req.token;
        const result = await service.getApplicationList(appscanToken);
        let filteredResults = [];
        if (result.code === 200) {
            var results = result.data.Items;
            filteredResults = results.map(a => {
                return { Id: a.Id, AppName: a.Name, HighIssues: a.HighIssues, MediumIssues: a.MediumIssues, LowIssues: a.LowIssues, BusinessImpact: a.BusinessImpact, LastUpdated: a.LastUpdated, TotalIssues: a.HighIssues + a.MediumIssues + a.LowIssues }
            })
            let sqlQuery = filteredResults.map(item => `(${item.AppName}, ${item.HighIssues}, ${item.MediumIssues}, ${item.LowIssues}, ${item.TotalIssues})`)
            const finalQuery = "INSERT INTO ApplicationStatistics (AppId, High, Medium, Low, Total) VALUES " + sqlQuery
            console.log(finalQuery)
            sql.query(connectionString, finalQuery, (err, rows) => {
                console.log(err)
                console.log(rows);
            });
            res.send(filteredResults);
        }
    } catch (err) {
        logger.error(`${err}`);
        return res.status(err.response.status).send(err.response.data.Message);
    }
}


module.exports = methods;