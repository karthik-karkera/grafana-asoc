const util = require('../utils/utils');
const constants = require('../utils/constants')

const log4js = require("log4js");
const logger = log4js.getLogger("igwService");

var methods = {}

methods.getApplicationList = async (appscanToken) => {
    const url = constants.ASOC_APPLICATION_LIST;
    return await util.httpRequest(url, appscanToken, "GET")
}

module.exports = methods;