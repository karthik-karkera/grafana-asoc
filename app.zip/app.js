const express = require('express');
const app = express();

app.get('/', (req, res) => {
    console.log('Test');
    res.send('Test')
})

app.listen('8001', () => {
    console.log('Running 8001')
})

